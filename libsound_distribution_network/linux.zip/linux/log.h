#ifndef LOG_H
#define LOG_H

#define debug(_tag, format, ...) 
#define info(_tag, format, ...) 
#define warn(_tag, format, ...) 
#define error(_tag, format, ...) 
#define pinfo(_tag, format, ...) 
#define pinfo2(_tag, format, ...)

#endif

