#ifndef THREAD_H
#define THREAD_H

#include "base.h"
#include "tinycthread.h"

#endif
