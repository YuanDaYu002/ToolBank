function echoFunctionCall(param1)
	param1["____THIS_IS_ADDED____"]="____THIS_IS_ADDED____";
	return param1;
end

