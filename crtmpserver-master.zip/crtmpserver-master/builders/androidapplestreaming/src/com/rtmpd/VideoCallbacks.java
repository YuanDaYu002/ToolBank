package com.rtmpd;

import java.util.HashMap;

public interface VideoCallbacks {
    public void EventAvailable(Object eventHashMap);
};

