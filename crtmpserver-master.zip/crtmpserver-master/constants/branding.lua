BRANDING_COMPANY_NAME="C++ RTMP"
BRANDING_WEB="www.rtmpd.com"
BRANDING_EMAIL="contact@rtmpd.com"

