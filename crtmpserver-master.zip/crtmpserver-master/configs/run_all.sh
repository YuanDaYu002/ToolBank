#!/bin/sh

./crtmpserver ./configs/all.debug.lua

